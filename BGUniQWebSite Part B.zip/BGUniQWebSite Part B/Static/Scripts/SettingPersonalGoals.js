document.querySelector('#btnHomePage').addEventListener("click", (e) => {
    e.preventDefault()
    window.location.href = "Index.html"
})
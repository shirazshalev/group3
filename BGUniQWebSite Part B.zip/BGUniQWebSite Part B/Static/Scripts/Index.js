// Update the welcome to be with the user full name
document.addEventListener('DOMContentLoaded', function () {
    let fullName = localStorage.getItem('fullName');
    if (fullName) {
        let welcomeUser = document.getElementById('welcomeUser');
        welcomeUser.textContent = `שלום, ${fullName}`;
    } else {
        let welcomeUser = document.getElementById('welcomeUser');
        welcomeUser.textContent = `שלום`;
    }
});

document.getElementById("btnCreditCalculator").addEventListener("click", (e) => {
    e.preventDefault()
    window.location.href = "GPACalculator.html"
})

document.getElementById("btnAcademicRecord").addEventListener("click", (e) => {
    e.preventDefault()
    window.location.href = "AcademicRecord.html"
})

document.getElementById("btnWhatIfCalculator").addEventListener("click", (e) => {
    e.preventDefault()
    window.location.href = "WhatIfCalculator.html"
})

document.getElementById("btnSetGoals").addEventListener("click", (e) => {
    e.preventDefault()
    window.location.href = "SettingPersonalGoals.html"
})
